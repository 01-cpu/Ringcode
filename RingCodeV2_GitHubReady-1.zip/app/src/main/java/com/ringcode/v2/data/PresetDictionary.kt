package com.ringcode.v2.data

data class Preset(val code:Int, val phrase:String, val call1:Int, val gap:Int, val call2:Int)

object PresetDictionary {
    val defaults = listOf(
        Preset(0,"I'm on my way",2,2,2), Preset(1,"Running late",2,2,4),
        Preset(2,"I'll be there soon",2,2,6), Preset(3,"At the location",2,2,8),
        Preset(4,"Emergency — need help",2,2,10), Preset(5,"Call me",2,6,2),
        Preset(6,"Can't make it",2,6,4), Preset(7,"All good",2,6,6),
        Preset(8,"Thinking of you",2,6,8), Preset(9,"Yes",2,6,10),
        Preset(10,"No",2,10,2), Preset(11,"Send me the details",2,10,4)
    )
}
