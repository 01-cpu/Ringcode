package com.ringcode.v2.protocol

data class RingPattern(val call1Seconds:Int,val gapSeconds:Int,val call2Seconds:Int)
object RingCodec {
    val ringBuckets = intArrayOf(2,4,6,8,10)
    val gapBuckets = intArrayOf(2,6,10,14,18,22,26,30)
    fun encode(code:Int): RingPattern {
        require(code in 0..199)
        val c1=code/(8*5); val g=(code/5)%8; val c2=code%5
        return RingPattern(ringBuckets[c1],gapBuckets[g],ringBuckets[c2])
    }
    fun decode(c1:Double,gap:Double,c2:Double):Int? {
        fun nearest(x:Double,b:IntArray,t:Double):Int? { val i=b.indices.minByOrNull{ kotlin.math.abs(x-b[it]) } ?: return null; return if(kotlin.math.abs(x-b[i])<=t)i else null }
        val a=nearest(c1,ringBuckets,1.0)?:return null; val b=nearest(gap,gapBuckets,2.0)?:return null; val c=nearest(c2,ringBuckets,1.0)?:return null
        return a*40+b*5+c
    }
}
