package com.ringcode.v2.telecom

import android.telecom.Call
import android.telecom.CallScreeningService
import com.ringcode.v2.protocol.RingCodec

class RingCodeCallScreeningService: CallScreeningService() {
    override fun onScreenCall(details: Call.Details) {
        // V2 keeps the screening hook isolated so whitelist/timing persistence can be added safely.
        // Do not reject the call here: the protocol needs the phone to ring long enough to measure.
        respondToCall(details, CallResponse.Builder().setDisallowCall(false).setRejectCall(false).setSkipCallLog(false).setSkipNotification(false).build())
    }
}
