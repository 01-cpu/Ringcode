package com.ringcode.v2.telecom

import android.telecom.Call
import android.telecom.InCallService
import java.util.concurrent.CopyOnWriteArrayList

class RingCodeInCallService : InCallService() {
    override fun onCallAdded(call: Call) { calls += call; super.onCallAdded(call) }
    override fun onCallRemoved(call: Call) { calls.remove(call); super.onCallRemoved(call) }
    companion object { val calls=CopyOnWriteArrayList<Call>() }
}
