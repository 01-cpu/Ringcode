package com.ringcode.v2.telecom

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.telecom.TelecomManager
import com.ringcode.v2.protocol.RingPattern

class CallTimingEngine(private val context: Context) {
    private val handler=Handler(Looper.getMainLooper())
    fun send(number:String, pattern:RingPattern, onState:(String)->Unit) {
        fun place(duration:Int, next:()->Unit) {
            onState("Calling… ${duration}s")
            val telecom=context.getSystemService(TelecomManager::class.java)
            telecom.placeCall(Uri.parse("tel:${Uri.encode(number)}"), android.os.Bundle())
            handler.postDelayed({ disconnectCurrent(); next() }, duration*1000L)
        }
        place(pattern.call1Seconds){ onState("Waiting… ${pattern.gapSeconds}s"); handler.postDelayed({ place(pattern.call2Seconds){ onState("Sent") } }, pattern.gapSeconds*1000L) }
    }
    private fun disconnectCurrent(){ RingCodeInCallService.calls.lastOrNull()?.disconnect() }
}
