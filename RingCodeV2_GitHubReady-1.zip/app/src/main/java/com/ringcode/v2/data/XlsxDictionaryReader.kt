package com.ringcode.v2.data

import android.content.Context
import android.net.Uri
import android.util.Xml
import java.io.InputStream
import java.util.zip.ZipFile

/** Lightweight .xlsx reader: reads the first worksheet and shared strings without adding Apache POI. */
object XlsxDictionaryReader {
    fun read(context: Context, uri: Uri): List<Preset> {
        val temp = java.io.File.createTempFile("ringcode", ".xlsx", context.cacheDir)
        context.contentResolver.openInputStream(uri)!!.use { input -> temp.outputStream().use { input.copyTo(it) } }
        return try { ZipFile(temp).use { zip -> parse(zip) } } finally { temp.delete() }
    }

    private fun parse(zip: ZipFile): List<Preset> {
        val shared = mutableListOf<String>()
        zip.getEntry("xl/sharedStrings.xml")?.let { parseShared(zip.getInputStream(it), shared) }
        val sheet = zip.getEntry("xl/worksheets/sheet1.xml") ?: return emptyList()
        val rows = mutableListOf<List<String>>()
        parseSheet(zip.getInputStream(sheet), shared, rows)
        val result = mutableListOf<Preset>()
        for ((index,row) in rows.withIndex()) {
            if (index == 0 && row.firstOrNull()?.lowercase()?.contains("code") == true) continue
            if (row.size < 5) continue
            val code=row[0].toIntOrNull() ?: continue
            val c1=row[2].toIntOrNull() ?: continue
            val gap=row[3].toIntOrNull() ?: continue
            val c2=row[4].toIntOrNull() ?: continue
            result += Preset(code, row[1], c1, gap, c2)
        }
        return result.sortedBy { it.code }
    }
    private fun parseShared(input:InputStream,out:MutableList<String>) {
        val p=Xml.newPullParser(); p.setInput(input,"UTF-8"); var event=p.eventType; var text=""; var inT=false
        while(event!=org.xmlpull.v1.XmlPullParser.END_DOCUMENT){ if(event==org.xmlpull.v1.XmlPullParser.START_TAG && p.name=="t") inT=true; if(event==org.xmlpull.v1.XmlPullParser.TEXT && inT) text+=p.text; if(event==org.xmlpull.v1.XmlPullParser.END_TAG && p.name=="t") inT=false; if(event==org.xmlpull.v1.XmlPullParser.END_TAG && p.name=="si"){out+=text;text=""}; event=p.next() }
    }
    private fun parseSheet(input:InputStream,shared:List<String>,rows:MutableList<List<String>>) {
        val p=Xml.newPullParser(); p.setInput(input,"UTF-8"); var event=p.eventType; var row=mutableListOf<String>(); var value=""; var type=""; var inV=false
        while(event!=org.xmlpull.v1.XmlPullParser.END_DOCUMENT){
            if(event==org.xmlpull.v1.XmlPullParser.START_TAG){ when(p.name){"row"->row=mutableListOf();"c"->type=p.getAttributeValue(null,"t") ?: "";"v"->inV=true} }
            else if(event==org.xmlpull.v1.XmlPullParser.TEXT && inV) value+=p.text
            else if(event==org.xmlpull.v1.XmlPullParser.END_TAG){ when(p.name){"v"->inV=false;"c"->{row += if(type=="s") shared.getOrNull(value.toIntOrNull() ?: -1) ?: "" else value; value=""};"row"->rows+=row} }
            event=p.next()
        }
    }
}
