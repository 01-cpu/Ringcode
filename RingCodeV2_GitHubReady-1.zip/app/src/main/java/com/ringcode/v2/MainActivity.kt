package com.ringcode.v2

import android.app.Activity
import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.telecom.TelecomManager
import android.view.LayoutInflater
import android.view.View
import android.widget.*
import com.ringcode.v2.data.Preset
import com.ringcode.v2.data.PresetDictionary
import com.ringcode.v2.data.XlsxDictionaryReader
import com.ringcode.v2.protocol.RingCodec
import com.ringcode.v2.telecom.CallTimingEngine
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var content: FrameLayout
    private var dictionary = PresetDictionary.defaults
    private val io=Executors.newSingleThreadExecutor()

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContentView(R.layout.activity_main); content=findViewById(R.id.content)
        findViewById<Button>(R.id.navPhone).setOnClickListener{showPhone()}; findViewById<Button>(R.id.navMessages).setOnClickListener{showMessages()}; findViewById<Button>(R.id.navNews).setOnClickListener{showNews()}; findViewById<Button>(R.id.navPlugins).setOnClickListener{showPlugins()}; showPhone(); requestDefaultDialer() }

    private fun inflate(id:Int):View=LayoutInflater.from(this).inflate(id,content,false)
    private fun showPhone(){ content.removeAllViews(); val v=inflate(R.layout.page_phone); content.addView(v)
        val number=v.findViewById<EditText>(R.id.number); val list=v.findViewById<LinearLayout>(R.id.recentList)
        list.addView(row("Alice Carter","+31 6 12345678","RingCode active")); list.addView(row("Bob Miller","+44 20 71234567","RingCode active")); list.addView(row("Unknown caller","+1 416 555 0123","Suspected spam"))
        v.findViewById<Button>(R.id.call).setOnClickListener{ val n=number.text.toString().trim(); if(n.isEmpty()) Toast.makeText(this,"Enter a number",Toast.LENGTH_SHORT).show() else { try { getSystemService(TelecomManager::class.java).placeCall(android.net.Uri.parse("tel:${android.net.Uri.encode(n)}"),Bundle()) } catch(e:Exception){Toast.makeText(this,"Unable to place call: ${e.message}",Toast.LENGTH_LONG).show()} } }
    }
    private fun row(name:String,number:String,status:String):View { val t=TextView(this); t.text="$name\n$number  •  $status"; t.textSize=16f; t.setTextColor(getColor(R.color.rc_ink)); t.setPadding(10,14,10,14); return t }

    private fun showMessages(){ content.removeAllViews(); val v=inflate(R.layout.page_messages); content.addView(v)
        val names=dictionary.map{it.phrase}; val input=v.findViewById<AutoCompleteTextView>(R.id.messageInput); input.setAdapter(ArrayAdapter(this,android.R.layout.simple_dropdown_item_1line,names)); input.threshold=1
        val spinner=v.findViewById<Spinner>(R.id.contactSpinner); spinner.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,arrayOf("Alice Carter • RingCode active","Bob Miller • RingCode active"))
        v.findViewById<Button>(R.id.send).setOnClickListener{ sendMessage(v,input.text.toString()) }
        v.findViewById<TextView>(R.id.active).setOnClickListener{openDictionaryPicker()}
    }
    private fun sendMessage(root:View,phrase:String){ val preset=dictionary.minByOrNull{ levenshtein(it.phrase.lowercase(),phrase.lowercase()) } ?: return; val number=if((root.findViewById<Spinner>(R.id.contactSpinner).selectedItem as String).startsWith("Bob")) "+442071234567" else "+31612345678"; val status=root.findViewById<TextView>(R.id.status); status.text="Preparing…"; val pattern=RingCodec.encode(preset.code); CallTimingEngine(this).send(number,pattern){runOnUiThread{status.text=it}}; val chat=root.findViewById<LinearLayout>(R.id.chat); val bubble=TextView(this); bubble.text="You  •  ${preset.phrase}"; bubble.textSize=17f; bubble.setTextColor(getColor(R.color.rc_ink)); bubble.setPadding(14,14,14,14); bubble.setBackgroundResource(R.drawable.bg_card); chat.addView(bubble); inputClear(root) }
    private fun inputClear(root:View){root.findViewById<AutoCompleteTextView>(R.id.messageInput).text.clear()}
    private fun levenshtein(a:String,b:String):Int { val d=Array(a.length+1){IntArray(b.length+1)}; for(i in 0..a.length)d[i][0]=i; for(j in 0..b.length)d[0][j]=j; for(i in 1..a.length)for(j in 1..b.length)d[i][j]=minOf(d[i-1][j]+1,d[i][j-1]+1,d[i-1][j-1]+if(a[i-1]==b[j-1])0 else 1); return d[a.length][b.length] }

    private fun showNews(){ content.removeAllViews(); val v=inflate(R.layout.page_news); content.addView(v); val list=v.findViewById<LinearLayout>(R.id.newsList); list.addView(article("World","Global leaders meet on climate action plan","New cooperation aims to accelerate clean-energy transition.")); list.addView(article("Technology","Breakthrough in clean energy storage","Researchers report progress in next-generation battery technology.")); v.findViewById<Button>(R.id.requestNews).setOnClickListener{Toast.makeText(this,"Content request queued for RingCodeAdmin",Toast.LENGTH_SHORT).show()} }
    private fun article(k:String,t:String,b:String):View{val tv=TextView(this);tv.text="$k\n$t\n$b";tv.textSize=16f;tv.setTextColor(getColor(R.color.rc_ink));tv.setPadding(0,14,0,14);return tv}
    private fun showPlugins(){content.removeAllViews();val v=inflate(R.layout.page_plugins);content.addView(v);v.findViewById<Button>(R.id.addPlugin).setOnClickListener{Toast.makeText(this,"Plugin installer coming next; sandboxing is part of the design.",Toast.LENGTH_SHORT).show()}}

    private fun openDictionaryPicker(){ val i=Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";addCategory(Intent.CATEGORY_OPENABLE)};startActivityForResult(i,41) }
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){super.onActivityResult(requestCode,resultCode,data);if(requestCode==41&&resultCode==RESULT_OK&&data?.data!=null){val uri=data.data!!;io.execute{try{val loaded=XlsxDictionaryReader.read(this,uri);runOnUiThread{if(loaded.isEmpty())Toast.makeText(this,"No valid presets found",Toast.LENGTH_LONG).show() else {dictionary=loaded;Toast.makeText(this,"Loaded ${loaded.size} presets",Toast.LENGTH_LONG).show();showMessages()}}}catch(e:Exception){runOnUiThread{Toast.makeText(this,"Spreadsheet error: ${e.message}",Toast.LENGTH_LONG).show()}}}}}
    private fun requestDefaultDialer(){ if(android.os.Build.VERSION.SDK_INT>=29){val rm=getSystemService(RoleManager::class.java);if(rm.isRoleAvailable(RoleManager.ROLE_DIALER)&&!rm.isRoleHeld(RoleManager.ROLE_DIALER)){startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_DIALER),90)}} }
}
