plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android { namespace = "com.ringcode.v2"; compileSdk = 35
    defaultConfig { applicationId = "com.ringcode.v2"; minSdk = 26; targetSdk = 35; versionCode = 20; versionName = "2.0.0" }
}
