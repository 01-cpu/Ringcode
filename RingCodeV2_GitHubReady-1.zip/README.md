# RingCode V2 — lightweight Kotlin/XML foundation

This is a from-scratch Android V2 foundation based on the RingCode concept: Phone, Messages, News and Plugins. It intentionally avoids Jetpack Compose and Apache POI. The `.xlsx` reader uses Android's ZIP/XML APIs so the preset-library feature stays lightweight.

## Preset Excel format
Create an `.xlsx` workbook with the first worksheet containing:

| code | phrase | call1 | gap | call2 |
|---:|---|---:|---:|---:|
| 0 | I'm on my way | 2 | 2 | 2 |
| 1 | Running late | 2 | 2 | 4 |
| 4 | Emergency — need help | 2 | 2 | 10 |

`code` must be 0–199. `call1` and `call2` are the ring buckets (2,4,6,8,10 seconds). `gap` is one of (2,6,10,14,18,22,26,30 seconds). The app reads shared strings and normal worksheet cell values.

## Current functional pieces
- Light modern XML UI system.
- Default-dialer role request on Android 10+.
- Phone page with dialing.
- Messenger with phrase search/autocomplete.
- RingCode 200-code encoder/decoder.
- Timed two-call sender using TelecomManager + InCallService disconnect hook.
- `.xlsx` preset library import.
- News page with weather/news/notice-board structure.
- Plugins page foundation.
- Call-screening service hook, intentionally non-blocking in this foundation.

## Important Android/telecom note
The telecom layer is isolated because default-dialer and call-screening behavior is OS/version/carrier dependent. Real device testing is required before treating automated hang-up and incoming timing measurement as production-ready.

## V2 design direction
The visual system uses a warm off-white canvas, deep blue ink, teal primary action, restrained amber accents, rounded 18–22dp surfaces, generous whitespace, and a native-feeling bottom navigation. The intent is to keep RingCode light without making it look like a prototype.
