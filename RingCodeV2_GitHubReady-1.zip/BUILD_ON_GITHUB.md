# Build RingCode V2 online (no Android Studio required)

This project is prepared for GitHub Actions. GitHub will build the Android APK in the cloud.

## 1. Create a GitHub repository

Create a new repository on GitHub. A public repository is the simplest option for the free GitHub Actions setup.

## 2. Upload this project

Upload the **contents of this ZIP**, not the ZIP file itself.

The repository root should contain files/folders like:

- `settings.gradle.kts`
- `build.gradle.kts`
- `app/`
- `.github/workflows/build-apk.yml`

## 3. Start the build

The workflow runs automatically after a push to `main` or `master`.

You can also open:

**GitHub → Actions → Build RingCode APK → Run workflow**

## 4. Download the APK

When the workflow finishes successfully:

**Actions → Build RingCode APK → latest successful run → Artifacts → RingCode-debug-apk**

Download the artifact ZIP and extract `app-debug.apk`.

## 5. Install on your Android phone

Copy `app-debug.apk` to the phone and open it. Android may ask you to allow installation from that source.

This is a **debug APK for testing**, not a Play Store release build.

## Notes

- The project uses Kotlin + XML views, not Jetpack Compose.
- The cloud workflow uses Java 17, Android SDK 35, and Gradle 8.9.
- The workflow intentionally builds a debug APK because it is signed automatically and is suitable for device testing.
- The telecom/Missed Call Protocol portions still need testing on a real Android device and may behave differently between carriers and Android versions.
- The XLSX preset-library reader is included in the project. The app expects the first worksheet to contain columns for `code`, `phrase`, `call1`, `gap`, and `call2`.
